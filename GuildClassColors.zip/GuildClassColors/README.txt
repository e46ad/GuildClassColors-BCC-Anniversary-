# Guild Class Colors 1.4.1 Feb 4th 26

A World of Warcraft TBC Classic (2.5.5) addon that enhances the guild roster by displaying class names in their corresponding class colors. Supports both English and Spanish clients.

## Features

- Automatically colors class names in the guild roster
- Supports all classic WoW classes
- Multi-language support (English and Spanish)
- Automatic language detection
- Updates dynamically when scrolling or when guild roster updates

## Installation

1. Download the latest release from the [releases page](https://github.com/e46ad/GuildClassColors-BCC-Anniversary-.git)
2. Extract the contents to your `World ofWorld of Warcraft\_anniversary_\Interface\AddOns directory
3. The path should look like: `Interface\AddOns\GuildClassColors\GuildClassColors.lua`
4. Restart World of Warcraft if it's running

## Color Scheme

The addon uses the standard WoW class colors:
- Warrior: Tan
- Mage: Light Blue
- Rogue: Yellow
- Druid: Orange
- Hunter: Green
- Shaman: Blue
- Priest: White
- Warlock: Purple
- Paladin: Pink

## Contributing

Feel free to submit issues and enhancement requests! 

## License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## Support

If you encounter any issues or have suggestions, please create an issue on the GitHub repository.

🚀 Guild Class Colors Anniversary is now LIVE on CurseForge!

The 2026 Anniversary Edition for TBC Classic (2.5.5) is officially available. Say goodbye to the boring monochromatic guild list and hello to full class-color clarity!

# GuildClassColors BCC (Anniversary 2026 Edition)

A lightweight, performance-optimized World of Warcraft addon for the **Burning Crusade Classic Anniversary (2.5.5)** client. This addon enhances the guild roster by replacing monochromatic text with vibrant, high-visibility class colors.

---

## 🚀 Key Features

* **Class-Colored Roster:** Instantly identifies members by their class color in the Guild Roster.
* **NEW: Modern Settings Menu:** Fully integrated into the **Interface > AddOns** game menu for easy configuration.
* **Dedicated Toggle Buttons:** One-click **ON**, **OFF**, and **Reload UI** buttons inside the settings panel.
* **Taint-Proof Design:** Features a "Hard-Gate" safety system that prevents `ADDON_ACTION_FORBIDDEN` errors when editing guild ranks.
* **Universal Language Support:** Automatically localizes class names for all client languages (EN, ES, DE, FR, RU, etc.).
* **Zero Performance Impact:** Consumes **0% CPU** unless your guild roster is actually open.

---

## 🛠 Commands

Type **`/gcc`** in-game to access the help menu or open settings:

| Command | Action |
| :--- | :--- |
| `/gcc` | Opens the Modern Settings Panel in the AddOns menu. |
| `/gcc on` | Enables class coloring via chat. |
| `/gcc off` | Disables class coloring via chat. |
| `/gcc links` | Opens an interactive popup to copy GitHub and CurseForge URLs. |

---

## 📂 Installation

1. Download the latest release from [GitHub](https://github.com/e46ad/GuildClassColors-BCC-Anniversary-.git).
2. Extract the `GuildClassColors` folder.
3. Paste it into your WoW directory:
   `World of Warcraft\_anniversary_\Interface\AddOns\`
4. Ensure the final path is:
   `...\AddOns\GuildClassColors\GuildClassColors.lua`
5. Restart World of Warcraft.

---

## 📋 Latest Changelog (v1.4.1)

* **ADDED:** Full Integration into the **Interface > AddOns** game menu.
* **ADDED:** Physical UI Buttons for **ON**, **OFF**, and **Reload UI** inside the settings panel.
* **ADDED:** Anniversary branding and Gold-text credits: **"© By Adamd-Spineshatter"**.
* **FIXED:** Resolved the "Chat Freeze" bug caused by legacy API calls in the 2.5.5 client.
* **IMPROVED:** Login message now dynamically shows status in Green (**ON**) or Red (**OFF**).

---

## ⚖️ License & Support

© 2026 **Adamd-Spineshatter**. Licensed under the **MIT License**.

If you encounter any issues or have suggestions, please create an issue on the GitHub repository or visit us on CurseForge!
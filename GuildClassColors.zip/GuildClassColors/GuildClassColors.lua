-- Guild Class Colors Addon
-- Version: 1.4.1 (Anniversary 2026 Edition)
-- Features: Modern AddOn List Integration, ON/OFF Toggle Buttons, Dual-Link Popup
-- Credits: Adamd-Spineshatter

local addonName = "GuildClassColors"
local addon = CreateFrame("Frame")
addon:RegisterEvent("ADDON_LOADED")

-- Default Settings (SavedVariable)
GCC_Settings = GCC_Settings or { enabled = true }

local CLASS_COLORS = {
    ["WARRIOR"] = "|cFFC79C6E", ["MAGE"] = "|cFF40C7EB", ["ROGUE"] = "|cFFFFFF69",
    ["DRUID"] = "|cFFFF7D0A", ["HUNTER"] = "|cFFABD473", ["SHAMAN"] = "|cFF0070DE",
    ["PRIEST"] = "|cFFFFFFFF", ["WARLOCK"] = "|cFF9482C9", ["PALADIN"] = "|cFFF58CBA"
}

---------------------------------------------------------
-- 1. PAINTER ENGINE
---------------------------------------------------------
local function UpdateGuildColors()
    if not GCC_Settings.enabled then return end
    if (GuildControlPopupFrame and GuildControlPopupFrame:IsVisible()) or not GuildFrame or not GuildFrame:IsVisible() then return end

    local offset = FauxScrollFrame_GetOffset(GuildListScrollFrame) or 0
    local numTotal = GetNumGuildMembers()
    
    for i = 1, (GUILDMEMBERS_TO_DISPLAY or 16) do
        local classText = _G["GuildFrameButton"..i.."Class"]
        if classText and classText:IsShown() then
            local index = offset + i
            if index <= numTotal then
                local _, _, _, _, _, _, _, _, _, _, classToken = GetGuildRosterInfo(index)
                if classToken then
                    local color = CLASS_COLORS[classToken:upper()] or "|cFFFFFFFF"
                    classText:SetText(color .. classToken .. "|r")
                end
            end
        end
    end
end

local Painter = CreateFrame("Frame", nil, GuildFrame)
Painter:SetScript("OnUpdate", function(self, elapsed)
    if not GCC_Settings.enabled then return end
    self.timer = (self.timer or 0) + elapsed
    if self.timer >= 0.1 then UpdateGuildColors(); self.timer = 0 end
end)

---------------------------------------------------------
-- 2. DUAL-LINK POPUP
---------------------------------------------------------
local function RefreshButtonColors(self, activeNum)
    local b1 = _G[self:GetName().."Button1"]
    local b2 = _G[self:GetName().."Button2"]
    if b1 and b2 then
        if activeNum == 1 then b1:SetText("|cff00ffccGitHub|r") b2:SetText("CurseForge")
        else b1:SetText("GitHub") b2:SetText("|cff00ffccCurseForge|r") end
    end
end

StaticPopupDialogs["GCC_LINKS"] = {
    text = "Copy the link (Ctrl+C):",
    button1 = "GitHub", button2 = "CurseForge", button3 = "Close",
    hasEditBox = 1, editBoxWidth = 350,
    OnAccept = function(self)
        local box = self.editBox or self.EditBox
        box:SetText("github.com/e46ad/GuildClassColors-BCC-Anniversary-")
        box:HighlightText()
        RefreshButtonColors(self, 1)
        return true
    end,
    OnCancel = function(self, data, reason)
        if reason == "clicked" then
            local box = self.editBox or self.EditBox
            box:SetText("legacy.curseforge.com/wow/addons/guild-class-colors-bcc-anniversary")
            box:HighlightText()
            RefreshButtonColors(self, 2)
            return true
        end
    end,
    OnShow = function(self)
        local box = self.editBox or self.EditBox
        box:SetText("github.com/e46ad/GuildClassColors-BCC-Anniversary-")
        box:SetFocus()
        box:HighlightText()
        RefreshButtonColors(self, 1)
    end,
    timeout = 0, whileDead = true, hideOnLogon = false,
}

---------------------------------------------------------
-- 3. THE SETTINGS PANEL (LISTED UNDER ADDONS)
---------------------------------------------------------
local category 

local function CreateSettingsUI()
    local panel = CreateFrame("Frame")
    panel.name = "GuildClassColors"

    local title = panel:CreateFontString(nil, "ARTWORK", "GameFontNormalLarge")
    title:SetPoint("TOPLEFT", 16, -16)
    title:SetText("|cff00ffccGuild Class Colors|r |cffffffffv1.4.1 BCC Anniversary 2026|r |cffFFD700Feb 26|r")

    -- NEW: Copyright/Author Line in Gold
    local author = panel:CreateFontString(nil, "ARTWORK", "GameFontNormal")
    author:SetPoint("TOPLEFT", title, "BOTTOMLEFT", 0, -5)
    author:SetText("|cffFFD700© By Adamd-Spineshatter|r")

    -- Checkbox
    local cb = CreateFrame("CheckButton", "GCC_EnabledCheckbox", panel, "InterfaceOptionsCheckButtonTemplate")
    cb:SetPoint("TOPLEFT", author, "BOTTOMLEFT", 0, -20)
    _G[cb:GetName().."Text"]:SetText(" Enabled")
    cb:SetChecked(GCC_Settings.enabled)
    cb:SetScript("OnClick", function(self)
        GCC_Settings.enabled = self:GetChecked()
        local statusText = GCC_Settings.enabled and "|cff00ff00ON|r" or "|cffFF0000OFF|r"
        print("|cff00ffccGCC:|r Status is now " .. statusText)
    end)

    -- ON Button
    local onBtn = CreateFrame("Button", nil, panel, "UIPanelButtonTemplate")
    onBtn:SetSize(80, 25)
    onBtn:SetPoint("TOPLEFT", cb, "BOTTOMLEFT", 0, -20)
    onBtn:SetText("|cff00ff00ON|r")
    onBtn:SetScript("OnClick", function()
        GCC_Settings.enabled = true
        GCC_EnabledCheckbox:SetChecked(true)
        print("|cff00ffccGCC:|r Status forced to |cff00ff00ON|r")
    end)

    -- OFF Button
    local offBtn = CreateFrame("Button", nil, panel, "UIPanelButtonTemplate")
    offBtn:SetSize(80, 25)
    offBtn:SetPoint("LEFT", onBtn, "RIGHT", 10, 0)
    offBtn:SetText("|cffFF0000OFF|r")
    offBtn:SetScript("OnClick", function()
        GCC_Settings.enabled = false
        GCC_EnabledCheckbox:SetChecked(false)
        print("|cff00ffccGCC:|r Status forced to |cffFF0000OFF|r")
    end)

    -- Reload Button
    local reloadBtn = CreateFrame("Button", nil, panel, "UIPanelButtonTemplate")
    reloadBtn:SetSize(170, 25)
    reloadBtn:SetPoint("TOPLEFT", onBtn, "BOTTOMLEFT", 0, -10)
    reloadBtn:SetText("Reload UI")
    reloadBtn:SetScript("OnClick", ReloadUI)

    -- Project Links Button
    local linkBtn = CreateFrame("Button", nil, panel, "UIPanelButtonTemplate")
    linkBtn:SetSize(170, 25)
    linkBtn:SetPoint("TOPLEFT", reloadBtn, "BOTTOMLEFT", 0, -10)
    linkBtn:SetText("Project Links")
    linkBtn:SetScript("OnClick", function() StaticPopup_Show("GCC_LINKS") end)

    -- Proper 2026 AddOns Tab Registration
    if Settings and Settings.RegisterCanvasLayoutCategory then
        category = Settings.RegisterCanvasLayoutCategory(panel, panel.name)
        category.ID = panel.name
        Settings.RegisterAddOnCategory(category)
    else
        InterfaceOptions_AddCategory(panel)
    end
end

---------------------------------------------------------
-- 4. STARTUP & SLASH COMMANDS
---------------------------------------------------------
addon:SetScript("OnEvent", function(self, event, arg1)
    if arg1 == addonName then
        if GCC_Settings.enabled == nil then GCC_Settings.enabled = true end
        
        CreateSettingsUI()

        SLASH_GCC1 = "/gcc"
        SlashCmdList["GCC"] = function(msg)
            msg = msg:lower():trim()
            if msg == "links" then
                StaticPopup_Show("GCC_LINKS")
            else
                if Settings and Settings.OpenToCategory then
                    Settings.OpenToCategory(category:GetID())
                else
                    InterfaceOptionsFrame_OpenToCategory("GuildClassColors")
                end
            end
        end

        local status = GCC_Settings.enabled and "|cff00ff00ON|r" or "|cffFF0000OFF|r"
        print("|cff00ffcc" .. addonName .. " v1.4.1 Status: " .. status .. ". Type |cffFFD700/gcc|r |cff00ffccfor options!|r")
        self:UnregisterEvent("ADDON_LOADED")
    end
end)
# CLAUDE.md - GuildClassColors BCC (v1.4.1)

**Project Goal:** Lightweight, performance-optimized class coloring for the WoW BCC Anniversary (2.5.5) guild roster.
**Developer:** Adamd-Spineshatter
**Compatibility:** World of Warcraft Anniversary Edition (2026)

---

## 🛠 Tech Stack & Standards
* **Language:** Lua (Blizzard WoW API)
* **Client Path:** `World of Warcraft\_anniversary_\Interface\AddOns\GuildClassColors\`
* **Core Principle:** "Zero-Idle" Parenting. Logic must only run when the `GuildFrame` is visible.
* **Safety:** Use "Hard-Gate" checks to prevent `ADDON_ACTION_FORBIDDEN` errors during rank edits.

## 🛠 Commands & UI
* **Primary Command:** `/gcc` (Opens the AddOns settings panel)
* **Utility Command:** `/gcc links` (Opens interactive URL popup)
* **Toggles:** Support for both `/gcc on/off` slash commands and physical UI buttons.

---

## 📝 Change Log & History

| Version | Date | Description |
| :--- | :--- | :--- |
| **1.4.1** | Feb 2026 | **Anniversary Update**: Modern AddOns menu integration. Added ON/OFF/Reload buttons. Added gold-text credits: "© By Adamd-Spineshatter". |
| **1.2.0** | Feb 2026 | **Stability Update**: Fixed Taint errors with Hard-Gate logic. Implemented 0.1s Force-Painter engine. Added interactive link popups. |
| **1.1.0** | Feb 2026 | **Optimization Update**: Fixed nil scroll arithmetic crashes. Added global language support and FrameTimer buffering. |
| **1.0.0** | Feb 2026 | Initial BCC Anniversary Edition. Core class color roster logic. |

---

## 🛠 Key Fixes Reference
* **Taint Prevention:** Never hook functions related to `GuildControlPopupFrame`. Use `IsVisible()` checks to suspend the Painter.
* **Scroll Fix:** Handle nil offsets in `FauxScrollFrame_GetOffset` to prevent `SecureScrollTemplates.lua:230` crashes.
* **Performance:** Ensure the `OnUpdate` script is attached to a frame parented to `GuildFrame`.

---

## 📂 Project Structure
* `GuildClassColors.toc`: Metadata and SavedVariables definition (`GCC_Settings`).
* `GuildClassColors.lua`: Main engine, UI generation, and event handling.
* `README.md`: User-facing documentation.
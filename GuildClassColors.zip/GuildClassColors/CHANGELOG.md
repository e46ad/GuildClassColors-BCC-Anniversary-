# GuildClassColors BCC (Anniversary 2026 Edition) Feb 4th 26

**Developer:** Adamd-Spineshatter  
**Release Date:** February 2026  
**Compatibility:** BCC Anniversary Edition 2.5.5 (2026)

Adds vibrant class colors to the guild roster for better visibility and a modernized UI experience.

---

## 🛠 Fixes & Improvements

### 1. Stability & Bug Fixes
* **Forbidden Action Resolved:** Implemented a "Hard-Gate" safety check that detects when the Guild Control window is open. This permanently fixes the `ADDON_ACTION_FORBIDDEN` error when saving rank changes.
* **Arithmetic Error Resolved:** Fixed the `SecureScrollTemplates.lua:230` crash by explicitly handling nil scroll offsets.
* **Combat Lockdown:** Integrated checks to ensure the addon remains dormant during combat, preventing UI errors during intense encounters.
* **Chat-Freeze Fix:** Rebuilt the command registration to prevent the legacy API bugs from locking up the player's chat box.

### 2. Performance Optimization
* **Force-Painter Engine:** Replaced the legacy throttle with a 0.1s painter engine. This ensures colors stay visible even when the Blizzard UI tries to overwrite them with white text.
* **Zero-Idle Parenting:** The addon logic is now parented to the Guild Frame, meaning it consumes **0% CPU** unless your roster is actually open on your screen.
* **Universal Localization:** Automatically supports all game languages (DE, FR, ES, RU, etc.) using internal client tables.

### 3. Visual & UI Features
* **NEW: Interface Options Panel:** Fully integrated into the **Interface > AddOns** menu.
* **Dedicated UI Buttons:** Added physical **ON**, **OFF**, and **Reload UI** buttons within the settings panel.
* **Interactive Teal Popups:** Added a custom link dialog via `/gcc links` featuring seafoam-colored buttons to toggle between GitHub and CurseForge URLs.
* **Custom Branding:** Updated the UI header and login greeting to include **Gold-text credits** and the **Feb 26** launch date.

---

## 🛠 Commands

Type **`/gcc`** in-game to access the settings and help:

| Command | Action |
| :--- | :--- |
| `/gcc` | Opens the Modern Settings Panel in the AddOns menu. |
| `/gcc links` | Opens the interactive URL popup. |

---

## 📝 Change Log

| Version | Description |
| :--- | :--- |
| **1.4.1** | **Anniversary Update:** Added modern AddOns menu integration. Added ON/OFF/Reload UI buttons. Updated branding to "BCC Anniversary 2026 Feb 26" with Gold-text credits. |
| **1.2.0** | **Stability Update:** Fixed "Forbidden Action" (Taint) errors. Implemented Force-Painter engine. Added interactive Teal link popups. |
| **1.1.0** | **Optimization Update:** Resolved "Arithmetic on Nil" scroll crashes. Added global language support. |
| **1.0.0** | Initial release. |

---

## 📂 Installation

1. Download the latest release.
2. Extract the `GuildClassColors` folder.
3. Paste it into your WoW directory:
   `World of Warcraft\_anniversary_\Interface\AddOns\`
4. Ensure the final path is:
   `World of Warcraft\_anniversary_\Interface\AddOns\GuildClassColors\`
5. Restart World of Warcraft.

---

## ⚖️ License & Copyright

© 2026 **Adamd-Spineshatter**. Licensed under the **MIT License**.